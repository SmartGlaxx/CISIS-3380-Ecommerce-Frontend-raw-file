import React, {useEffect, useReducer, useState} from 'react'
import  reducer  from '../reducers/app-reducer'
import Axios from 'axios'
import API from '../resourses/api'
import { useParams } from 'react-router-dom'
const CURRENTUSER = "CURRENTUSER"; const LOGGEDIN = 'LOGGEDIN' ; const SETTRANSPARENTLOADING = "SETTRANSPARENTLOADING";
const LOADING = 'LOADING'; const MENUOPEN = 'MENUOPEN', TIMELINEPOSTS ='TIMELINEPOSTS', 
ALERT='ALERT'; const ALLUSERS = "ALLUSERS"; const TEMPALLUSERS = 'TEMPALLUSERS';
const SETCUSERFOLLOWINGS = "SETCUSERFOLLOWINGS"; const SETNEWTEMPUSER = 'SETNEWTEMPUSER'
const POSTCREATED = 'POSTCREATED'; const SETSIDEBAR = 'SETSIDEBAR' ; const USERCLICKED = 'USERCLICKED';
const SETFETCHEDUSER = 'SETFETCHEDUSER'; const COMMENTSENT = 'COMMENTSENT';
const CURRENTUSERPARSED = 'CURRENTUSERPARSED' ; const TESTVALUE = 'TESTVALUE'; const LAZYLOADING = 'LAZYLOADING';
const SETCHATUSERNAME = 'SETCHATUSERNAME'; const SETREPLYSENT = 'SETREPLYSENT';
const SCROLLINTOVIEW = "SCROLLINTOVIEW" ; const SETSEARCHTERM = "SETSEARCHTERM"; 
const SIGNUPSUCCESSFUL = "SIGNUPSUCCESSFUL"; const SET_PRODUCTS = "SET_PRODUCTS"


const getLoggedIn = ()=>{
    let value
    if(localStorage.getItem('LoggedIn') == "true"){
        value = localStorage.getItem('LoggedIn')
    }else{
        value = localStorage.getItem('LoggedIn')
    }
    return value
}


const getCurrentUser = ()=>{
    let value
    if(localStorage.getItem('CurrentUser')){
         value = localStorage.getItem('CurrentUser')
    }else{
        value = {}
    }
    return value
}


const AppContext = React.createContext()
const initialState = {
//     //auth-context
//     signupSuccessful : false,
    loggedIn : getLoggedIn(),
//     registered : false,
    currentUserParsed : {},
    currentUser : getCurrentUser(),
//     tempCurrentUser : {},
//     verified : false,

//     //page-context
    alert : {status : false, msg : ''},
    loading : false,
//     lazyLoading : false,
//     transparentLoading : false,
    sidebarOpen : false,
//     timelineposts : [],
//     allUsers : [],
//     tempAllUsers : [],
//     postcreated : false,

//     userClicked : false,
//     fetchedUser : {},

//     commentSent : false,
//     replySent : false,
//     testValue : false,

//     scrollIntoViewValue : false,
//     searchTermValue : ''
        products: [],
        featured: []
}

export const AppProvider = ({children})=>{
    const [state, dispatch] = useReducer(reducer, initialState)
    // const [alert, setAlert] = useState(false)
    
    const setAlert = (value)=>{
        dispatch({type: ALERT, payload: value})
    }
//     const allUsersUrl = `${API}/user`
//     const posturl = `${API}/posts`

//     // useEffect(()=>{
//     //     console.log('smart search state', state.searchTerm)

//     // },[state.searchTerm])
//     //SET LOADING 
    const setLoading =(value)=> {
            dispatch({type : LOADING, payload : value})
     }

//      const setTransparentLoading = (value)=>{
//          dispatch({type: SETTRANSPARENTLOADING, payload : value})
//      }

//     //FETCH TIME-LINE POSTS
//     const fetchTimelinePosts = async(url)=>{
      
//         const options = {
//             url: url,
//             method : "GET",
//             headers : {
//                 "Accept" : "application/json",
//                 "Content-Type" : "application/json;charset=UTF-8"
//             }
//         }
//        // dispatch({type : LOADING, payload : true})
       
//         const result = await Axios(options)
//         const {response, allPosts} = result.data
//         if(response == 'Success' && allPosts){
//            const newTimelinePosts = allPosts.sort((a,b)=>{
//                return new Date(b.createdAt) - new Date(a.createdAt)
//            })
//             dispatch({type : TIMELINEPOSTS, payload : newTimelinePosts})
//         }else if(response == 'Fail'){
//             dispatch({type: ALERT, payload : "An error occured"})
//         }
        
//     }


const fetchProducts = async()=>{
    dispatch({type: LOADING, payload: true})
    try{
        const productsData = await Axios.get('http://localhost:5001/products/all')
        const {products} = productsData.data
        if(products){
            dispatch({type: SET_PRODUCTS, payload: products})
            dispatch({type: LOADING, payload: false})
        }else{
            dispatch({type: ALERT, payload: {status : true, msg : "Error fetching products"}})            
        }
    }catch(error){
        dispatch({type: ALERT, payload: {status : true, msg : "Error fetching products"}})
        dispatch({type: LOADING, payload: false})
    }
}

useEffect(() => {
  fetchProducts()
}, []);
   
    
//     //FETCH TIME-LINE POSTS USEEFFECT
//     useEffect(()=>{
//         const currentUserObj = state.currentUser  
//         if(Object.keys(currentUserObj).length != 0){
//             const checkeUser = state.currentUser
//             let parsedCheckeUser = ''
            
//             //CHECK IF CURRENTUSER IS IN LOCALSTORAGE
//           if(JSON.parse(checkeUser)._id !== null){
//                 parsedCheckeUser = JSON.parse(checkeUser)
//                let {_id, username} = parsedCheckeUser
//                 fetchTimelinePosts(`${posturl}/${_id}/${username}/timeline`)
//              }
//              if(state.currentUser._id !== null){
//                 parsedCheckeUser = state.currentUser 
//                let {_id, username} = parsedCheckeUser
//                 fetchTimelinePosts(`${posturl}/${_id}/${username}/timeline`)
//              }
//         }
    
//     },[state.postcreated, state.userClicked])


//     //FETCH OTHER USER TIMELINE POSTS

//     const setTimelinePosts = (value)=>{
//         dispatch({type : TIMELINEPOSTS, payload : value})
//     }

// //     //FETCH ALL USERS
//     const fetchAllUsers = async(url)=>{
//     // dispatch({type : LOADING, payload : true})
//     await Axios(url).then(result =>{
    
//         const {response} = result.data
        
//         if(response == 'Success'){
//             ///dispatch({type : LOADING, payload : false})
//             const {usersData} = result.data
//             dispatch({type : ALLUSERS, payload : usersData})
//         }else if(response == 'Fail'){
//             //dispatch({type : LOADING, payload : false})
//             dispatch({type: ALERT, payload : "An error occured fetching other users"})
//         }
//     })
        
//     }

// //     //FETCH ALL USERS USEEFFECT
//     useEffect(()=>{
//         // if(state.timelineposts.length == 0){
//                 fetchAllUsers(allUsersUrl) 
//         // }
//     },[state.testValue, state.postcreated])

// //     //FETCH ALL USERS WHEN MORE BUTTON IS CLICKED
//     const setTempAllusers = (value)=>{
//         dispatch({type : TEMPALLUSERS, payload : value})
//     }

 //     //SET CURRENT USER
   const setCurrentUser = (value)=>{
      
        localStorage.setItem('CurrentUser',JSON.stringify(value))
    }

// //    //SET USERDATA WHEN CHAGES OCCURS - LIKE FOLLOWING / UNFOLLOWING
//     const setNewCurrentUser = (value)=>{
//             localStorage.setItem('CurrentUser',JSON.stringify(value))
            
//            // dispatch({type : SETNEWTEMPUSER, payload : value})
//            dispatch({type : CURRENTUSER, payload : value})
//     }

//    const setPostCreated =(value)=>{
//         dispatch({type : POSTCREATED, payload : value})
//    }

   const fetchCurrentUser=async(userUrl)=>{

    const options = {
        url: userUrl,
        method : "GET",
        headers : {
            "Accept" : "application/json",
            "Content-Type" : "application/json;cjarset=UTF-8"
        }
    }
   
    const result = await Axios(options)
    const {response, user} = result.data
    
        if(response == "Success" && user){
            dispatch({type : CURRENTUSERPARSED , payload : user})
            //return window.location.href = '/'
        }else{
            dispatch({type : CURRENTUSERPARSED , payload : {}})
        }
   }
   useEffect(()=>{
    const currentUserObj = state.currentUser     
    if(Object.keys(currentUserObj).length != 0){
        const {id} = JSON.parse(state.currentUser)
    
        fetchCurrentUser(`${API}/user/get-user/${id}`)
    }
   },[state.currentUser
    // ,state.testValue
])


const isTop = window.scrollY < 10; // Change the threshold as needed
useEffect(() => {
    const handleScroll = () => {
      if (isTop !== state.scrolling) {
        setScrolling(isTop);
      }
    };

    window.addEventListener('scroll', handleScroll);

    // return () => {
    //   window.removeEventListener('scroll', handleScroll);
    // };
  }, [state.scrolling]);

// //    //SET LOGGED-IN
   const setLoggedIn =(value)=>{
    
       if(value == true){
        localStorage.setItem('LoggedIn',"true")
       }else if(value == false){
        localStorage.setItem('LoggedIn',"false")
       }
         
    //    dispatch({type : LOGGEDIN, payload : value})
   }

//    //OPEN SIDE BAR
   const openSidebar = ()=>{
       dispatch({type : SETSIDEBAR})
   }

//    //CHECK IF A USER PROFILE IS CLICKED
//    const setUserClicked =()=>{
//        dispatch({type : USERCLICKED})
//    }

// //SET OTHER USER
// const setFetchedUser = (value)=>{
//     dispatch({type : SETFETCHEDUSER, payload : value})
// }


// //TRIGGER COMMENT SENT
// const setCommentSent = (value)=>{
//     dispatch({type : COMMENTSENT, payload : value})
// }


// const setTestValue = (value)=>{
//     dispatch({type : TESTVALUE, payload : value})
// }

// //SET LAZY-LOADING FOR POSTS
// const setLazyLoading = (value)=>{
//     dispatch({type : LAZYLOADING, payload : value})
// }

// //SET USERNAME FOR CHAT MATE
// const setChatUser = (value)=>{
//     dispatch({type : SETCHATUSERNAME, payload : value})
// }

// const setReplySent = (value)=>{
//     dispatch({type : SETREPLYSENT, payload : value})
// }

// //scroll-into-view function
// const setScrollIntoViewValue = (value)=>{
//     dispatch({type : SCROLLINTOVIEW, payload : value })
// }

// //set the search term
// const setSearchTermValue = (value)=>{    
//     dispatch({type : SETSEARCHTERM , payload : value})
// }

// //set signup succesful to notify user on login page
// const setSignupSuccessful = (value)=>{
//     dispatch({type : SIGNUPSUCCESSFUL, payload : value})
// }



    return <AppContext.Provider value={{
        ...state, setCurrentUser, setLoggedIn, openSidebar, setAlert
        //  setLoading, setTransparentLoading, setCurrentUser, setLoggedIn, setLazyLoading, setNewCurrentUser, 
        // setTempAllusers, setPostCreated, setUserClicked, setFetchedUser, setSignupSuccessful,
        // setTimelinePosts, setCommentSent,  setTestValue, setChatUser, setReplySent, setScrollIntoViewValue,
        // setSearchTermValue
    }}>
    {children}
    </AppContext.Provider>
}

export const UseAppContext = ()=>{
    return React.useContext(AppContext)
}

