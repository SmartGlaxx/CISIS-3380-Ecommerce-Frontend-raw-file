import React, {useState, useEffect} from 'react'
import {FaBars} from 'react-icons/fa6'
import "./Navbar.css"
import logo from "../../assets/images/logo.jpg"
import { Link } from 'react-router-dom'
import { links } from '../../resourses/links'
import { UseAppContext } from '../../Contexts/app-context'

const Navbar = () => {
    const {loggedIn, setLoggedIn, setCurrentUser, openSidebar, currentUserParsed} = UseAppContext()
    const [scrolling, setScrolling] = useState(false);
    const {role} = currentUserParsed
   
    useEffect(() => {
        const handleScroll = () => {
        const isTop = window.scrollY < 10; // Change the threshold as needed
        if (isTop !== scrolling) {
            setScrolling(isTop);
        }
        };

        window.addEventListener('scroll', handleScroll);

        return () => {
        window.removeEventListener('scroll', handleScroll);
        };
    }, [scrolling]);

    const navBarStyle = {
        position: "fixed", top:"0", width: "100%", left:"0", zIndex: "10",
        backgroundColor: scrolling ? 'transparent' : 'var(--background-color)', 
        transition: 'background-color 0.3s ease-in-out',
    };

    const setLoggedInAndNavigate = (value) =>{
        setLoggedIn(value)
        setCurrentUser({})
        return window.location.href = '/sign-in'
    }
  return (
    <div className='nav-container' style={navBarStyle}>
        <Link to="/">
            <img src={logo} alt='logo' className='logo' />
        </Link>
        <ul className='nav-links-desktop'>
            {
                links.map(link =>{
                    const {id, name, url, icon, color} = link
                    return <li key={id} className='nav-link-desktop'>
                        <Link to={`${url}`} className='link'>
                            <span className='link-name' style={{display: "flex"}}><div style={{color:color, marginRight: "0.5rem",marginTop:"0.1rem"}}>{icon}</div>{name}</span>
                        </Link>
                    </li>
                })
            }
        </ul>
        
        <div className='right-buttons'>
        {
            loggedIn == "true" ? <button className='sign-out-button-desktop' onClick={()=>setLoggedInAndNavigate(false)}>Sign out</button> :
            <Link to={`/sign-in`}><button className='sign-out-button-desktop'>Sign in</button></Link>
        }
        {
             <Link to={`/admin`}>
            <button className='admin-button-desktop'>
                Admin
            </button>    
            </Link> 
        }
            <button onClick={openSidebar} className='mobile-nav-button'><FaBars /></button>
        </div>
    </div>
  )
}

export default Navbar