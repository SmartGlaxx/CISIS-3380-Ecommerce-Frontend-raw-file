const API = 'http://localhost:5001'


export default API