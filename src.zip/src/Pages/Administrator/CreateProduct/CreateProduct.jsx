// import React, { useState } from 'react';
// import Axios from 'axios';
// import Alert from '@mui/material/Alert';
// import { FormControlLabel, Checkbox, Radio, RadioGroup, Button, 
//   TextField, Container, Paper } from '@mui/material';
// import "./CreateProduct.css"
// import AdminHome from "../AdminHome/AdminHome"

// const CreateProduct = () => {
//   const [alert, setAlert] = useState({status: false, message: ""})
//   const [error, setError] = useState({status: false, message: ""})
//   const [productData, setProductData] = useState({
//     productName: '',
//     price: '',
//     description: '',
//     productCategory: '',
//     manufacturer: '',
//     colors: [],
//     featured: false,
//     freeShipping: false,
//     inventory: '',
//   });

//   const [imageFiles, setImageFiles] = useState([]);

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     let modifiedValue = value; 
  
//     if (name === "price" || name === "inventory" ) {
//       modifiedValue = value.replace(/[^0-9]/g, '');
//     }
  
//     setProductData({...productData,[name]: modifiedValue});
//   };

//   const handleImageUpload = async (e) => {
//     const files = Array.from(e.target.files);

//     if (files.length + imageFiles.length > 5) {
//       alert('You can upload 5 images or less');
//       return;
//     }

//     setImageFiles([...imageFiles, ...files]);
//   };

//   const handleCheckboxChange = (color) => {
//     const updatedColors = [...productData.colors];

//     if (updatedColors.includes(color)) {
//       const index = updatedColors.indexOf(color);
//       updatedColors.splice(index, 1);
//     } else {
//       updatedColors.push(color);
//     }

//     setProductData({
//       ...productData,
//       colors: updatedColors,
//     });
//   };

//   const handleRadioChange = (e) => {
//     const { name, value } = e.target;
  
//     setProductData({
//       ...productData,
//       [name]: value === 'true',
//     });
//   };

//   const createProduct = async () => {
//     try {
//       const formData = new FormData();
//       if(imageFiles.length < 2){
//         setAlert({status: true, message: "Please select at least 2 images"})
//         setTimeout(() => {
//           setAlert({status: false, message: ''})
//         }, 4000)
//         return
//       }
//       imageFiles.forEach((file) => formData.append('images', file));

//       const { data: { images } } = await Axios.post('http://localhost:5001/products/upload-image', formData);

//       const productImages = images.map((image) => image.src);
      
//       const {productName, price, description, productCategory, manufacturer,
//         colors, featured, freeShipping, inventory} = productData
        
//         const options = {
//           url: `http://localhost:5001/products/create`,
//           method : "POST",
//           headers : {
//               "Accept" : "application/json",
//               "Content-Type" : "application/json"
//           },
//           data: {
//             productName,
//             price,
//             productImages: productImages,
//             description,
//             productCategory,
//             manufacturer,
//             colors,
//             featured,
//             freeShipping,
//             inventory,
//           }
//       }

//       const result = await Axios(options)

//       const { response, createdProduct } = result.data

//       if (response === 'Success') {
//         setAlert({status: true, message: response})
//         setTimeout(() => {
//           setAlert({status: false, message: ''})
//         }, 4000)
//       } else if (response === 'Fail') {
//         const { message } = result.data
//         setError({status: true, message: message})
//         setTimeout(() => {
//           setError({status: false, message: ''})
//         }, 4000)
//       }

//       setProductData({
//         productName: '',
//         price: '',
//         description: '',
//         productCategory: '',
//         manufacturer: '',
//         colors: [''],
//         featured: false,
//         freeShipping: false,
//         inventory: '',
//       });

//       setImageFiles([]);
//     } catch (error) {
//       console.error(error);
//     }
//   };

//   return (
//     <>
//       <AdminHome />
//       <Container component="main" maxWidth="sm">
//         {
//           alert.status && <div className='alert'>
//             <Alert severity="error">{alert.message}</Alert>
//           </div>
//         }
//         <h1 className='create-product-title'>Create Product</h1>
//         <Paper elevation={3} className='create-product-paper'>
//           <form className="form">
//             <TextField
//               fullWidth
//               label="Product Name"
//               name="productName"
//               value={productData.productName}
//               onChange={handleInputChange}
//               margin="normal"
//             />
//             <TextField
//               fullWidth
//               label="Product Price"
//               name="price"
//               value={productData.price}
//               onChange={handleInputChange}
//               margin="normal"
//             />
//             <TextField
//               fullWidth
//               label="Product Description"
//               name="description"
//               value={productData.description}
//               onChange={handleInputChange}
//               multiline
//               rows={4}
//               margin="normal"
//             />
//             <TextField
//               fullWidth
//               label="Product Category"
//               name="productCategory"
//               value={productData.productCategory}
//               onChange={handleInputChange}
//               margin="normal"
//             />
//             <TextField
//               fullWidth
//               label="Product Manufacturer"
//               name="manufacturer"
//               value={productData.manufacturer}
//               onChange={handleInputChange}
//               margin="normal"
//             />
//             <div className='checkbox'>
//               {['Red', 'Blue', 'Green', 'Yellow', 'Purple', 'Orange', 'Pink', 'Brown', 'Black', 'White'].map((color) => (
//                 <FormControlLabel
//                   key={color}
//                   control={
//                     <Checkbox
//                       checked={productData.colors.includes(color)}
//                       onChange={() => handleCheckboxChange(color)}
//                       color="primary"
//                     />
//                   }
//                   label={color}
//                 />
//               ))}
//             </div>
//             <RadioGroup
//               name="featured"
//               value={productData.featured.toString()}
//               onChange={handleRadioChange}
//               row
//             >
//               <FormControlLabel
//                 value="true"
//                 control={<Radio color="primary" />}
//                 label="Yes"
//               />
//               <FormControlLabel
//                 value="false"
//                 control={<Radio color="primary" />}
//                 label="No"
//               />
//             </RadioGroup>
//             <RadioGroup
//               name="freeShipping"
//               value={productData.freeShipping.toString()}
//               onChange={handleRadioChange}
//               row
//             >
//               <FormControlLabel
//                 value="true"
//                 control={<Radio color="primary" />}
//                 label="Yes"
//               />
//               <FormControlLabel
//                 value="false"
//                 control={<Radio color="primary" />}
//                 label="No"
//               />
//             </RadioGroup>
//             <TextField
//               fullWidth
//               label="Inventory"
//               name="inventory"
//               value={productData.inventory}
//               onChange={handleInputChange}
//               margin="normal"
//             />
//             <input
//               type="file"
//               name="images"
//               multiple
//               onChange={handleImageUpload}
//               className='image-picker'
//             />
//             <Button
//               className="create-product-button"
//               onClick={createProduct}
//               variant="contained"
//               sx={{
//                 backgroundColor: 'var(--background-color-8)',
//                 color: 'var(--color3)',
//                 '&:hover': {
//                   backgroundColor: 'var(--background-color)',
//                   color: 'var(--color4)'
//                 },
//               }}
//             >
//               Create Product
//             </Button>
//           </form>
//         </Paper>
//       </Container>
//     </>
//   );
// };

// export default CreateProduct;




import React, { useEffect, useState } from 'react';
import Axios from 'axios';
import Alert from '@mui/material/Alert';
import { FormControlLabel, Checkbox, Radio, RadioGroup, Button, 
  TextField, Container, Paper, InputLabel, Select, MenuItem } from '@mui/material';
  
import "./CreateProduct.css"
import AdminHome from "../AdminHome/AdminHome"
import { UseAppContext } from '../../../Contexts/app-context';
import { Navigate } from 'react-router-dom';

const CreateProduct = () => {
  const {loggedIn, currentUserParsed} = UseAppContext()
  const [alert, setAlert] = useState({status: false, message: ""})
  const [error, setError] = useState({status: false, message: ""})
  const {role} = currentUserParsed
  const [productData, setProductData] = useState({
    productName: '',
    price: '',
    description: '',
    productCategory: '',
    manufacturer: '',
    colors: [],
    featured: false,
    freeShipping: false,
    inventory: '',
  });

  const [imageFiles, setImageFiles] = useState([]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    let modifiedValue = value; 
  
    if (name === "price" || name === "inventory" ) {
      modifiedValue = value.replace(/[^0-9]/g, '');
    }
  
    setProductData({...productData,[name]: modifiedValue});
  };

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);

    if (files.length + imageFiles.length > 5) {
      setAlert({status: true, message: "You can upload 5 images or less"})
      setTimeout(() => {
        setAlert({status: false, message: ''})
      }, 4000)
      return;
    }

    setImageFiles([...imageFiles, ...files]);
  };

  const handleCheckboxChange = (color) => {
    const updatedColors = [...productData.colors];

    if (updatedColors.includes(color)) {
      const index = updatedColors.indexOf(color);
      updatedColors.splice(index, 1);
    } else {
      updatedColors.push(color);
    }

    setProductData({...productData,colors: updatedColors});
  };

  const handleRadioChange = (e) => {
    const { name, value } = e.target;
    
    setProductData({...productData,[name]: value === 'true'});
  };

  const handleCategoryChange = (event) => {
    setProductData({...productData, productCategory: event.target.value});
  };

  const createProduct = async () => {
    try {
      const formData = new FormData();
      if(imageFiles.length < 2){
        setAlert({status: true, message: "Please select at least 2 images"})
        setTimeout(() => {
          setAlert({status: false, message: ''})
        }, 4000)
        return
      }
      imageFiles.forEach((file) => formData.append('images', file));

      const { data: { images } } = await Axios.post('http://localhost:5001/products/upload-image', formData);

      const productImages = images.map((image) => image.src);
      
      const {productName, price, description, productCategory, manufacturer,
        colors, featured, freeShipping, inventory} = productData
        
        const options = {
          url: `http://localhost:5001/products/create`,
          method : "POST",
          headers : {
              "Accept" : "application/json",
              "Content-Type" : "application/json"
          },
          data: {
            productName,
            price,
            productImages: productImages,
            description,
            productCategory,
            manufacturer,
            colors,
            featured,
            freeShipping,
            inventory,
          }
      }

      const result = await Axios(options)

      const { response, createdProduct } = result.data

      if (response === 'Success') {
        setAlert({status: true, message: response})
        setTimeout(() => {
          setAlert({status: false, message: ''})
        }, 4000)
      } else if (response === 'Fail') {
        const { message } = result.data
        setError({status: true, message: message})
        setTimeout(() => {
          setError({status: false, message: ''})
        }, 4000)
      }

      setProductData({
        productName: '',
        price: '',
        description: '',
        productCategory: '',
        manufacturer: '',
        colors: [''],
        featured: false,
        freeShipping: false,
        inventory: '',
      });

      setImageFiles([]);
    } catch (error) {
      console.error(error);
    }
  };


  useEffect(() => {
    const timer = setTimeout(() => {
      if (loggedIn === "false" || role !== "admin") {
        return  <Navigate to='/' /> 
      }
    }, 2000); 
    return () => clearTimeout(timer);
  }, []); 


  return (
    <>
      <AdminHome />
      <Container component="main" maxWidth="sm" >
        {
          alert.status && <div className='alert'>
            <Alert severity="error">{alert.message}</Alert>
          </div>
        }
        <h1 className='create-product-title'>Create Product</h1>
        <Paper elevation={3} className='create-product-paper' style={{opacity:'var(--paper-opacity-2)'}}>
          <form className="form">
            <TextField
              fullWidth
              label="Product Name"
              name="productName"
              value={productData.productName}
              onChange={handleInputChange}
              margin="normal"
            />
            <TextField
              fullWidth
              label="Product Price"
              name="price"
              value={productData.price}
              onChange={handleInputChange}
              margin="normal"
            />
            <TextField
              fullWidth
              label="Product Description"
              name="description"
              value={productData.description}
              onChange={handleInputChange}
              multiline
              rows={4}
              margin="normal"
            />
            <InputLabel id="category-label">Category</InputLabel>
            <Select
              labelId="category-label"
              id="category-select"
              style={{width:"100%"}}
              value={productData.productCategory}
              onChange={handleCategoryChange}
              label="Category"
            >
              <MenuItem value="electronics">Electronics</MenuItem>
              <MenuItem value="fashion">Fashion and Apparel</MenuItem>
              <MenuItem value="home">Home and Living</MenuItem>
              <MenuItem value="beauty">Beauty and Personal Care</MenuItem>
              <MenuItem value="sports">Sports and Outdoors</MenuItem>
              <MenuItem value="toys">Toys and Games</MenuItem>
            </Select>
            <TextField
              fullWidth
              label="Product Manufacturer"
              name="manufacturer"
              value={productData.manufacturer}
              onChange={handleInputChange}
              margin="normal"
            />
            <div className='checkbox'>
              {['Red', 'Blue', 'Green', 'Yellow', 'Grey', 'Orange', 'Pink', 'Brown', 'Black', 'White'].map((color) => (
                <FormControlLabel
                  key={color}
                  control={
                    <Checkbox
                      checked={productData.colors.includes(color)}
                      onChange={() => handleCheckboxChange(color)}
                      color="primary"
                    />
                  }
                  label={color}
                />
              ))}
            </div>
            <hr />
            Featured<RadioGroup
              name="featured"
              value={productData.featured.toString()}
              onChange={handleRadioChange}
              row
            >
              <FormControlLabel
                value="true"
                control={<Radio color="primary" />}
                label="Yes"
              />
              <FormControlLabel
                value="false"
                control={<Radio color="primary" />}
                label="No"
              />
            </RadioGroup>
            Free shipping<RadioGroup
              name="freeShipping"
              value={productData.freeShipping.toString()}
              onChange={handleRadioChange}
              row
            >
              <FormControlLabel
                value="true"
                control={<Radio color="primary" />}
                label="Yes"
              />
              <FormControlLabel
                value="false"
                control={<Radio color="primary" />}
                label="No"
              />
            </RadioGroup>
            <TextField
              fullWidth
              label="Inventory"
              name="inventory"
              value={productData.inventory}
              onChange={handleInputChange}
              margin="normal"
            />
            <input
              type="file"
              name="images"
              multiple
              onChange={handleImageUpload}
              className='image-picker'
            />
            <Button
              className="create-product-button"
              onClick={createProduct}
              variant="contained"
              sx={{
                backgroundColor: 'var(--background-color-8)',
                color: 'var(--color3)',
                '&:hover': {
                  backgroundColor: 'var(--background-color)',
                  color: 'var(--color4)'
                },
              }}
            >
              Create Product
            </Button>
          </form>
        </Paper>
      </Container>
    </>
  );
};

export default CreateProduct;
