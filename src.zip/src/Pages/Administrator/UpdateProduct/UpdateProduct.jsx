import React, { useState, useEffect } from 'react';
import Axios from 'axios';
import { Navigate, useNavigate, useParams } from 'react-router-dom';
import { FormControlLabel, Checkbox, Grid, Radio, RadioGroup, Button, 
    TextField, Container, Paper, InputLabel, Select, MenuItem } from '@mui/material';
    
import Alert from '@mui/material/Alert';
import "./UpdateProduct.css"
import AdminHome from "../AdminHome/AdminHome"
import { UseAppContext } from '../../../Contexts/app-context';

const UpdateProduct = () => {
  const {loggedIn, currentUserParsed} = UseAppContext()
  const [alert, setAlert] = useState({status: false, message: ""})
  const [error, setError] = useState({status: false, message: ""})
  const [newImages, setNewImages] = useState([]);
  const [imageFiles, setImageFiles] = useState([]);
  const {id} = useParams();
  const navigate = useNavigate()
  const {role} = currentUserParsed
  const [productData, setProductData] = useState({
    productName: '',
    price: '',
    description: '',
    productCategory: '',
    manufacturer: '',
    colors: [],
    featured: false,
    freeShipping: false,
    inventory: '',
  });


  useEffect(() => {
    const fetchProductData = async () => {
      try {
        const response = await Axios.get(`http://localhost:5001/products/product/${id}`);
        console.log(response)
        const fetchedProductData = response.data.product; 
        setProductData(fetchedProductData);
      } catch (error) {
        console.error('Error fetching product data:', error);
      }
    };

    fetchProductData();
  }, [id]);

//   useEffect(() => {
//     Axios.get(`http://localhost:5001/products/update/${id}`)
//       .then(response => {
//         setProductData(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching product data:', error);
//       });
//   }, [id]);

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     if(name=="price"){
//         const value = value.replace(/[^0-9]/g, '')
        
//     }
//     setProductData({
//       ...productData,
//       [name]: value,
//     });
//   };

// const handleImageUpload = async () => {
//     try {
//       const formData = new FormData();
//       newImages.forEach((file) => formData.append('images', file));

//       const { data: { images } } = await Axios.post(`http://localhost:5001/products/upload-image`, formData);

//       // Update the product with the new images
//       setProductData({
//         ...productData,
//         productImages: [...product.productImages, ...images.map((image) => image.src)],
//       });

//       // Clear the state for new images
//       setNewImages([]);
//     } catch (error) {
//       console.error(error);
//     }
//   };

const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);

    if (files.length + imageFiles.length > 5) {
      setAlert({status: true, message: "You can upload 5 images or less"})
        setTimeout(() => {
          setAlert({status: false, message: ''})
        }, 4000)
      return;
    }

    setImageFiles([...imageFiles, ...files]);
  };

//   const handleImageDelete = async (index) => {
//     try {
//       // Remove the image at the specified index
//       const updatedImages = [...product.productImages];
//       updatedImages.splice(index, 1);

//       // Update the product without the deleted image
//       setProduct({
//         ...product,
//         productImages: updatedImages,
//       });
//     } catch (error) {
//       console.error(error);
//     }
//   };


const handleInputChange = (e) => {
    const { name, value } = e.target;
    let modifiedValue = value; 
  
    if (name === "price" || name === "inventory" ) {
      modifiedValue = value.replace(/[^0-9]/g, '');
    }
  
    setProductData({...productData,[name]: modifiedValue});
  };

  const handleCheckboxChange = (color) => {
    const updatedColors = [...productData.colors];

    if (updatedColors.includes(color)) {
      const index = updatedColors.indexOf(color);
      updatedColors.splice(index, 1);
    } else {
      updatedColors.push(color);
    }

    setProductData({...productData,colors: updatedColors});
  };

  const handleRadioChange = (e) => {
    const { name, value } = e.target;
    setProductData({...productData,[name]: value === 'true'});
  };

  const handleCategoryChange = (event) => {
    setProductData({...productData, productCategory: event.target.value});
  };


const updateProduct = async () => {
    try {
      const formData = new FormData();
      let newProductImages = []
      if(imageFiles.length == 1){
        setAlert({status: true, message: "Please select at least 2 images"})
        return
      }
      if(imageFiles.length > 0){
        imageFiles.forEach((file) => formData.append('images', file));

        const { data: { images } } = await Axios.post('http://localhost:5001/products/upload-image', formData);
  
        newProductImages = images.map((image) => image.src);
      }
      

      
      const {productName, price, productImages, description, productCategory, manufacturer,
        colors, featured, freeShipping, inventory} = productData

      const options = {
        url: `http://localhost:5001/products/update/${id}`,
        method: "PATCH",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
        data: {
          productName,
          price,
          productImages: newProductImages.length>0 ? newProductImages : productImages ,
          description,
          productCategory,
          manufacturer,
          colors,
          featured,
          freeShipping,
          inventory,
        }
        
      }
      
      const result = await Axios(options)
      const { response, product } = result.data

      if (response === 'Success') {
        setAlert({status: true, message: response})
        setTimeout(() => {
          setAlert({status: false, message: ''})
        }, 4000)
      } else if (response === 'Fail') {
        const { message } = result.data
        setError({status: true, message: message})
        setTimeout(() => {
          setError({status: false, message: ''})
        }, 4000)
      }

    //   setProductData({
    //     productName: '',
    //     price: '',
    //     description: '',
    //     productCategory: '',
    //     manufacturer: '',
    //     colors: [''],
    //     featured: false,
    //     freeShipping: false,
    //     inventory: '',
    //   });

    //   setImageFiles([]);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      if (loggedIn === "false" || role !== "admin") {
        return  <Navigate to='/' /> 
      }
    }, 2000); 
    return () => clearTimeout(timer);
  }, []); 

  return (
    <>
    <AdminHome />
    <Container component="main" maxWidth="sm">
    {
      alert.status && <div className='admin-alert'>
        <Alert severity="error">{alert.message}</Alert>
      </div>
    }
    <h1 className='update-product-title'>Update {productData.productName}</h1>
      <Paper elevation={3} className='update-product-paper' style={{opacity:'var(--paper-opacity-2)'}}>
        <form>
          <TextField
            fullWidth
            label="Product Name"
            name="productName"
            value={productData.productName}
            onChange={handleInputChange}
            margin="normal"
          />
          <TextField
            fullWidth
            label="Product Price"
            name="price"
            value={productData.price}
            onChange={handleInputChange}
            margin="normal"
            inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }} 
          />
          <TextField
            fullWidth
            label="Product Description"
            name="description"
            value={productData.description}
            onChange={handleInputChange}
            multiline
            rows={4}
            margin="normal"
          />
          {/* <TextField
            fullWidth
            label="Product Category"
            name="productCategory"
            value={productData.productCategory}
            onChange={handleInputChange}
            margin="normal"
          /> */}
          <InputLabel id="category-label">Category</InputLabel>
            <Select
              labelId="category-label"
              id="category-select"
              style={{width:"100%"}}
              value={productData.productCategory}
              onChange={handleCategoryChange}
              label="Category"
            >
              <MenuItem value="electronics">Electronics</MenuItem>
              <MenuItem value="fashion">Fashion and Apparel</MenuItem>
              <MenuItem value="home">Home and Living</MenuItem>
              <MenuItem value="beauty">Beauty and Personal Care</MenuItem>
              <MenuItem value="sports">Sports and Outdoors</MenuItem>
              <MenuItem value="toys">Toys and Games</MenuItem>
            </Select>
          <TextField
            fullWidth
            label="Product Manufacturer"
            name="manufacturer"
            value={productData.manufacturer}
            onChange={handleInputChange}
            margin="normal"
          />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)' }}>
            {['Red', 'Blue', 'Green', 'Yellow', 'Grey', 'Orange', 'Pink', 'Brown', 'Black', 'White'].map((color) => (
              <FormControlLabel
                key={color}
                control={
                  <Checkbox
                    checked={productData.colors.includes(color)}
                    onChange={() => handleCheckboxChange(color)}
                    color="primary"
                  />
                }
                label={color}
              />
            ))}
          </div>
          <br/>
          <label>Free shipping</label>
          <RadioGroup
            row
            name="freeShipping"
            value={productData.freeShipping.toString()}
            onChange={handleRadioChange}
          >
            <FormControlLabel value="true" control={<Radio />} label="Yes" />
            <FormControlLabel value="false" control={<Radio />} label="No" />
          </RadioGroup>
          <br/>
          <label>Featured</label>
          <RadioGroup
            row
            name="featured"
            value={productData.featured.toString()}
            onChange={handleRadioChange}
          >
            <FormControlLabel value="true" control={<Radio />} label="Yes" />
            <FormControlLabel value="false" control={<Radio />} label="No" />
          </RadioGroup>
          <TextField
            fullWidth
            label="Inventory"
            name="inventory"
            value={productData.inventory}
            onChange={handleInputChange}
            margin="normal"
          />



    <div>      
      <Grid container spacing={2}>
        {productData.productImages && productData.productImages.map((image, index) => (
          <Grid item key={index}>
            <Paper elevation={3}>
              <img src={image} alt={`Product Image ${index}`} className='update-image' />
            </Paper>
          </Grid>
        ))}
      </Grid>

      <div className='update-image-display' gutterBottom>
        Upload New Images
      </div>

      <input type="file" 
      name="images" 
      multiple 
      className='image-picker'
      onChange={handleImageUpload} />
    </div>
      <Button
        type="button"
        variant="contained"
        onClick={updateProduct}        
        sx={{
          backgroundColor: 'var(--background-color-8)',
          color: 'var(--color3)',
          '&:hover': {
            backgroundColor: 'var(--background-color)',
            color: 'var(--color4)'
          },
        }}
      
      >
        Update Product
      </Button>
    </form>
      </Paper>
    </Container>
    </>
  );
};

export default UpdateProduct;
