import React from 'react'
import { Navbar, Sidebar, Footer, Backdrop} from '../../Components'
import { UseAppContext } from '../../Contexts/app-context'

const Cart = () => {
  const {loggedIn, currentUserParsed} = UseAppContext()

  return (
    <div>
      
      <Navbar />
      <Sidebar />
      <Backdrop />
      {loggedIn == "true" ?
    <div>{currentUserParsed.email}</div>
    : <div>Log in</div>}
      <Footer />
      </div>

  )
}

export default Cart