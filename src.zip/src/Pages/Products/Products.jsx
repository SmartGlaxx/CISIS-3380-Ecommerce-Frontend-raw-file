import React from 'react'
import { Navbar, Sidebar, Footer, Backdrop } from '../../Components'
import "./products.css"

const Products = () => {
  return (
    <div className='products'>
      
      <Navbar />
      <Sidebar />
      <Backdrop />
      Products
      <Footer />
      </div>
  )
}

export default Products