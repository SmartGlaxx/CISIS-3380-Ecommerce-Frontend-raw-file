import React from 'react'
import { UseAppContext } from '../../../Contexts/app-context'
import { Link } from 'react-router-dom'

const DealsSection = () => {
    const {products} = UseAppContext()

    const dealProducts = products.filter(product =>{
        return product.price <= 500
    })
  return (<div className='deals'> 
  <div style={{background:'var(--background-color-8)', opacity: "0.8",
  width:"100%", height:"100%", position: "absolute", left:"0", top:"0", zIndex: "0"}}></div>
    <h3 className='deals-title'>Deals and Promotions</h3>
    <div className='deals-products'>
        {
            dealProducts.map(product =>{
                const {_id, productName, price} = product
                return <Link to={`/product/${_id}`} className='deals-product'>
                     <div className='deals-image-container'>
                        <div className='deals-price'>${price}</div>
                        <img src={product.productImages[0]} alt={`img_${product._id}`} className='deals-image' />
                    </div>
                    <div className='deals-product-name'>
                        {productName}
                    </div>
                </Link>
            })
        }
        </div>
  </div>
  )
}

export default DealsSection