import React from 'react'
import { useRef } from 'react'
import { FaChevronLeft, FaChevronRight } from 'react-icons/fa6'
import { UseAppContext } from '../../../Contexts/app-context'
import { Link } from 'react-router-dom'

const FeaturedSection = () => {
    const {featured} = UseAppContext()
    const nextRef = useRef()
    const prevRef = useRef()
    const itemRef = useRef()
    const formListRef = useRef()
    
  const setNext =()=>{
    const widthItem = itemRef.current.offsetWidth;
    formListRef.current.scrollLeft += widthItem
  }
  
  const setPrev = () =>{
    const widthItem = itemRef.current.offsetWidth ;
    formListRef.current.scrollLeft -= widthItem
  }

  const featuredProducts = () => {
    return featured.map(product => (
      <Link to={`product/${product._id}`} key={product._id} className='item' ref={itemRef}>
        <img src={product.productImages[0]} alt={`img_${product._id}`} className='featured-image' />
        {/* <div className='content'>
          {product.description}
        </div> */}
      </Link>
    ));
  };
  
  return (
     <div className='featured'>
        <h3 className='featured-title'>Featured</h3>
      <div id="formList" ref={formListRef} >
        <div id="list">
          {featuredProducts()}
        </div>
      </div>
      <div className="direction" >
        <button id="prev" ref={prevRef} onClick={setPrev}><FaChevronLeft /></button>
        <button id="next" ref={nextRef} onClick={setNext}><FaChevronRight/></button>
      </div>
    </div>
  )
}

export default FeaturedSection