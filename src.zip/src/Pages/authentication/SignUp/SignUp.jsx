import React,{useState, useEffect} from 'react';
import { Link, useNavigate } from 'react-router-dom';
// import { Snackbar } from '@mui/material';
// import './signup.css'
// import API from '../../../Utils/api';
// import Button from '@mui/material/Button';
// import { useState, useEffect } from 'react'
// import {FaExclamationCircle, FaWindowClose} from 'react-icons/fa'
import Axios from 'axios'
// import {Link, useNavigate} from 'react-router-dom'
import { UseAppContext } from '../../../Contexts/app-context'
// import LoadingIcons from 'react-loading-icons'
// import { Row, Col } from 'react-bootstrap';
import Alert from '@mui/material/Alert';
import "./SignUp.css"
import { Button, Typography, TextField } from '@mui/material';

const SignUp =()=>{ 
    const {loggedIn, loading, setCurrentUser, currentUser} = UseAppContext()
    const [error, setError] = useState({status: false, msg :''})
    const [formValues, setFormValues] = useState({
        firstname : "",
        lastname : "",
        email : '',
        password1 : "",
        password2 : "",
    })
    const navigate = useNavigate()

    //Snackbar Alert start
   
  const [open, setOpen] = React.useState(false);
  
  const handleError = (status, message) => {
    setOpen(true);
    setError({status : status, msg : message})
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };
  //Snackbar Alert ends

  const setSignupValues =(data)=>{
    setCurrentUser(data) 
    // setTransparentLoading(false)
  }


  //close alert box
//   const closeAlertBox = ()=>{
//     setAlertMsg(false)
// }

    const setValues =(e)=>{
        let name = e.target.name
        let value = e.target.value

        setFormValues(prev => {
            return{...prev, [name] : value}
        })
    }



    const signUp = async(e)=>{
      
      e.preventDefault()
      const { firstname, lastname, email, password1, password2} = formValues
     
        if(!firstname){
          setError({status : true, msg : "Please enter Your first name"})
          setTimeout(()=>{
             return setError({status : false, msg :''})
          }, 4000)
       }else if(!lastname){
          setError({status : true, msg : "Please enter Your last name"})
          setTimeout(()=>{
              setError({status : false, msg :''})
          }, 4000)
      }else if(!email){
          setError({status : true, msg : "Please enter Your E-mail"})
          setTimeout(()=>{
              setError({status : false, msg :''})
          }, 4000)
      }else if(password2.length == 0 || password1.length == 0){
          setError({status : true, msg : "Please enter and comfirm your password"})
          setTimeout(()=>{
              setError({status : false, msg :''})
          }, 4000)
      } else if(password2.length < 8 || password1.length < 8){
        setError({status : true, msg :'Password must be 8 characters or more'})
        setTimeout(()=>{
            setError({status : false, msg :''})
        }, 4000)
    }else{
            if(password2 !== password1){
              setError({status : true, msg :'Password mismatch'})
              setTimeout(()=>{
                  setError({status : false, msg :''})
              }, 4000)
           }else{
            const options = {
                url: `http://localhost:5001/auth/create-user`,
                method : "POST",
                headers : {
                    "Accept" : "application/json",
                    "Content-Type" : "application/json"
                },
                data:{
                    firstname : firstname, 
                    lastname : lastname,
                    email : email,
                    password : password1
                }
            }

            setTimeout(()=>{
              setError({status : true, msg :"Please check your network connection"})
            },10000)
            setTimeout(()=>{
              setError({status : false, msg :""})
            },16000)
            const result = await Axios(options)
            const {response, userValue} = result.data
            // const id = user._id
            // console.log(user)
            
            if(response === 'Success'){
                setSignupValues(userValue)
                return window.location.href = `/sign-in`
                // setAlertMsg({status : true, msg : "Please check your email to verify your account"})
                
            }else if(response === 'Fail'){
                const {message} = result.data
                handleError(true, message)
                setTimeout(()=>{
                    setError({status : false, msg :''})
                }, 4000)
            }

          }
        }
    }
//scroll to top of page
    useEffect(() => {
        window.scrollTo(0, 0)
        // setTransparentLoading(false)
      }, [])
    
    if(loading){
        return <div style={{width: "100%",height : "100vh", 
        display: 'div', placeItems: "center"}}>
           <LoadingIcons.Puff       stroke="#555" strokeOpacity={.9} />
       </div>
    }


    return (
    // <div className='signup' >
    //     <div className='signup-heading' xs={12} sm={6}>
    //         <h2 className='title'>Smart E-commerce</h2
    //     </div>
    //     <div className='signup-form' xs={12} sm={6} >
            
    //         {
    //             error.status && <div >alert
    //             {/* <Alert severity="error">{error.msg}</Alert> */}
    //           </div>
    //         }
    //         <div>
    //              <h3 className='sign-up-title'>Sign Up</h3>
    //              <input className='signup-input' value ={formValues.firstname}  onChange={setValues} type='text' name='firstname' placeholder='Firstname'/>
    //              <input className='signup-input' value ={formValues.lastname}  onChange={setValues} type='text' name='lastname' placeholder='Lastname'/>
    //             <input className='signup-input' value ={formValues.username}  onChange={setValues} type='text' name='username' placeholder='Username'/>
    //             <input className='signup-input' value ={formValues.email}  onChange={setValues} type='email' name='email' placeholder='E-Mail'/>
    //             <input className='signup-input' value ={formValues.password1}  onChange={setValues} type='password' name='password1' placeholder='Password'/>
    //             <input className='signup-input' value ={formValues.password2}  onChange={setValues} type='password' name='password2' placeholder='Comfirm Password'/>
    //             {/* <Button className='btn'  onClick={signUp}>Sign up</Button> */}
    //           <div className='auth-btns'>
    //             <span className='auth-signup-btn2' onClick={signUp}>Sign up</span>
                
    //           </div>
    //           <div className='auth-alt-text'>Already have an account? <br/><Link to='/signin' className='auth-signup-btn' >Sign in</Link></div>
    //         </div>
    //     </div>
    // </div>

    <div className='signup' >
    <div className='signup-heading' >
      <h1>
        Smart E-commerce
      </h1>
    </div>
    <div className='signup-form' >
    {
          error.status && <div className='sign-up-alert' >
          <Alert severity="error">{error.msg}</Alert>
        </div>
      }
      <div className='sign-up-form'>
        <h6 className='sign-up-title'>
          Sign Up
        </h6>
        <TextField
          className='signup-input'
          value={formValues.firstname}
          onChange={setValues}
          type='text'
          name='firstname'
          label='Firstname'
          margin="normal"
          required
        />
        <TextField
          className='signup-input'
          value={formValues.lastname}
          onChange={setValues}
          type='text'
          name='lastname'
          label='Lastname'
          margin="normal"
          required
        />
        <TextField
          className='signup-input'
          value={formValues.email}
          onChange={setValues}
          type='email'
          name='email'
          label='E-Mail'
          margin="normal"
          required
        />
        <TextField
          className='signup-input'
          value={formValues.password1}
          onChange={setValues}
          type='password'
          name='password1'
          label='Password'
          margin="normal"
          required
        />
        <TextField
          className='signup-input'
          value={formValues.password2}
          onChange={setValues}
          type='password'
          name='password2'
          label='Comfirm Password'
          margin="normal"
          required
        />
        <div className='auth-btns'>
          <Button  
          sx={{
            backgroundColor: 'var(--background-color-9)',
            color: 'var(--color3)',
            border: '1px solid var(--background-color-9)',
            '&:hover': {
              backgroundColor: 'var(--background-color-8)',
              color: 'var(--color3)',
              border: '1px solid var(--background-color-8)'
            },
          }}
          onClick={signUp} variant="contained">
            Sign up
          </Button>
        </div>
        <div className='auth-alt-text'>
          Already have an account? <br />
          <Link to='/sign-in' className='auth-signup-btn'>
            Sign in
          </Link>
        </div>
      </div>
    </div>
  </div>
)}
 
export default SignUp