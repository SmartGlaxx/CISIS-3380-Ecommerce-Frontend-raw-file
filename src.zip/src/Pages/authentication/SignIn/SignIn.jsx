// import React from 'react';
// import './signin.css'
// import API from '../../../resourses/api';
// import { useState, useEffect } from 'react'
// import Axios from 'axios'
// import {Link, useParams} from 'react-router-dom'
// import { UseAppContext } from '../../../Contexts/app-context'  

// const SignIn =()=>{
//     const {loading, loggedIn, currentUser, setCurrentUser, setLoggedIn} = UseAppContext()
//     const [error, setError] = useState({status: false, msg :''})
//     const [formValues, setFormValues] = useState({
//         email : '',
//         password : ""
//     })

//     const {activity} = useParams() 
    
//   const [open, setOpen] = React.useState(false);
  
//   const handleError = (status, message) => {
//     setOpen(true);
//     setError({status : status, msg : message})
//   };

//   const handleClose = (event, reason) => {
//     if (reason === 'clickaway') {
//       return;
//     }

//     setOpen(false);
//   };


//     const setLoginValues =(value, loginData)=>{
//         setCurrentUser(loginData)
//         setLoggedIn(value)
//     }
//     const setValues =(e)=>{
//         const name = e.target.name
//         const value = e.target.value
//         setFormValues(prev => {
//             return{...prev, [name] : value}
//         })
//     }

//     const signIn = async(e)=>{
//          try{
//           e.preventDefault()
//         const {email, password} = formValues
//         if(!email || !password){
//             setError({status : true, msg : "Please enter E-mail and Password"})
//             setTimeout(()=>{
//                 setError({status : false, msg :''})
//             }, 4000)
//         }

//         if(password.length < 8){
//           setError({status : true, msg : "Password must be 8 characters or more"})
//           setTimeout(()=>{
//               setError({status : false, msg :''})
//           }, 4000)
//       }


//             const options = {
//                 url: `${API}/auth/sign-in`,
//                 method : "POST",
//                 headers : {
//                     "Accept" : "application/json",
//                     "Content-Type" : "application/json;cjarset=UTF-8"
//                 },
//                 data:{
//                     email : email,
//                     password : password
//                 }
//             }
           
//             const result = await Axios(options)
//             const {response, userValue} = result.data
            
//             if(response === 'Success'){
//                 setLoginValues(true, userValue)
//                 return window.location.href = '/'
//             }else if(response === 'Fail'){
//                 const {message} = result.data
//                 handleError(true, message)
//                 setTimeout(()=>{
//                     setError({status : false, msg :''})
//                 }, 4000)
//             }
//          }catch(error){
//           setError({status : true, msg :"Sign-in not successful"})
//           setTimeout(()=>{
//             setError({status : false, msg :''})
//         }, 4000)
//          }
//     }

 
// useEffect(() => {
//     window.scrollTo(0, 0)    
//   }, [])

//     if(loading){
//         return <div style={{width: "100%",height : "100vh", 
//         display: 'div', placeItems: "center"}}>
//            <LoadingIcons.Puff       stroke="#555" strokeOpacity={.9} />
//        </div>
//     }
//     return (
//     <div className='signin' >

//         <div className='signin-heading' xs={12} sm={6} >
//             <div className='title'>Smart E-commerce</div>
//         </div>
//         <div className='signin-form' xs={12} sm={6} >
         
//             {
//                 error.status && <div >{error.msg}
//                 <Alert severity="error">{error.msg}</Alert>
//               </div>
                
//             }
           
//             <div>
//                  <h3 className='sign-in-title'>Welcome Back</h3>
//                 <input className='signin-input' value ={formValues.email} onChange={setValues} 
//                  type='text' name='email' placeholder='E-mail/Username' required/>
//                 <input className='signin-input' value ={formValues.password}  onChange={setValues} 
//                 type='password' name='password' placeholder='Password' required/>
//               <div className='auth-btns'>
//                 <button className='auth-signin-btn2' onClick={signIn}>Sign in</button>
//               </div>
//               <div className='auth-alt-text'>New user? <Link to='/sign-up' className='auth-signup-btn' >Register</Link> an account</div>
//             </div>
//         </div>
//     </div>
// )}

// export default SignIn








import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { TextField, Button, Paper, Snackbar } from '@mui/material';
import Axios from 'axios';
import { UseAppContext } from '../../../Contexts/app-context';
import Alert from '@mui/material/Alert';
import "./signin.css";

const SignIn = () => {
  const { loading, loggedIn, currentUser, setCurrentUser, setLoggedIn } = UseAppContext();
  const [error, setError] = useState({ status: false, msg: '' });
  const [formValues, setFormValues] = useState({
    email: '',
    password: ""
  });

  const { activity } = useParams();

  const [open, setOpen] = React.useState(false);

  const handleError = (status, message) => {
    setOpen(true);
    setError({ status: status, msg: message });
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };

  const setLoginValues = (value, loginData) => {
    setCurrentUser(loginData);
    setLoggedIn(value);
  };

  const setValues = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setFormValues((prev) => {
      return { ...prev, [name]: value };
    });
  };

  const signIn = async (e) => {
    try {
      e.preventDefault();
      const { email, password } = formValues;
      if (!email || !password) {
        setError({ status: true, msg: "Please enter E-mail and Password" });
        setTimeout(() => {
          setError({ status: false, msg: '' });
        }, 4000);
      }

      if (password.length < 8) {
        setError({ status: true, msg: "Password must be 8 characters or more" });
        setTimeout(() => {
          setError({ status: false, msg: '' });
        }, 4000);
      }

      const options = {
        url: `http://localhost:5001/auth/sign-in`,
        method: "POST",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json;charset=UTF-8"
        },
        data: {
          email: email,
          password: password
        }
      };

      const result = await Axios(options);
      const { response, userValue } = result.data;

      if (response === 'Success') {
        setLoginValues(true, userValue);
        return window.location.href = '/';
      } else if (response === 'Fail') {
        const { message } = result.data;
        handleError(true, message);
        setTimeout(() => {
          setError({ status: false, msg: '' });
        }, 4000);
      }
    } catch (error) {
      setError({ status: true, msg: "Sign-in not successful" });
      setTimeout(() => {
        setError({ status: false, msg: '' });
      }, 4000);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // if (loading) {
  //   return (
  //     <div style={{ width: "100%", height: "100vh", display: 'flex', justifyContent: "center", alignItems: "center" }}>
  //       <LoadingIcons.Puff stroke="#555" strokeOpacity={0.9} />
  //     </div>
  //   );
  // }

  return (
    <div className='signin'>
      <div className='signin-heading'>
        <h1>Smart E-commerce</h1>
      </div>
      <div className='signin-form'>
      {
          error.status && <div className='sign-in-alert' >
          <Alert severity="error">{error.msg}</Alert>
        </div>
      }
        <div  className='sign-in-form'>
          <h3 className='sign-in-title'>Sign in</h3>
          <TextField
            className='signin-input'
            value={formValues.email}
            onChange={setValues}
            type='text'
            name='email'
            label='E-mail'
            margin="normal"
            required
          />
          <TextField
            className='signin-input'
            value={formValues.password}
            onChange={setValues}
            type='password'
            name='password'
            label='Password'
            margin="normal"
            required
          />
          <div className='auth-btns'>
            {/* <Button 
            style={{background:"var(--background-color-9)"}}
            onClick={signIn} variant="contained"
            >
              Sign up
            </Button> */}
            <Button
              sx={{
                backgroundColor: 'var(--background-color-9)',
                color: 'var(--color3)',
                border: '1px solid var(--background-color-9)',
                '&:hover': {
                  backgroundColor: 'var(--background-color-8)',
                  color: 'var(--color3)',
                  border: '1px solid var(--background-color-8)'
                },
              }}
              onClick={signIn}
              variant="contained"
            >
              Sign in
            </Button>


          </div>
          <div className='auth-alt-text'>
            New user? <Link to='/sign-up' className='auth-signin-btn'>Register</Link> an account
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignIn;
