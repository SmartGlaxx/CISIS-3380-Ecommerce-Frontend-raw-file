import React from 'react'
import { Navbar, Sidebar, Footer, Backdrop } from '../../Components'

const Checkout = () => {
  return (
    <div>
      
      <Navbar />
      <Sidebar />
      <Backdrop />
      Checkout
      <Footer />
      </div>
  )
}

export default Checkout