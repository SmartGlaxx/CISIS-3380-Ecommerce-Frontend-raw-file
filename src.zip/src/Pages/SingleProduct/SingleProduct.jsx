import React from 'react'
import { Navbar, Sidebar, Footer } from '../../Components'

const SingleProduct = () => {
  return (
    <div>
      
      <Navbar />
      <Sidebar />
      SingleProduct
      <Footer />
      </div>
  )
}

export default SingleProduct